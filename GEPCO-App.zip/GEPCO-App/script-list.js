
function saveReference() {
  const refNumber = document.getElementById('refNumber').value;
  const saveCheckbox = document.getElementById('saveCheckbox');

  // Check if the reference input is empty and prevent submission
  if (refNumber.trim() === '') {
    alert('Please enter a reference number.');
    return;  // Stop execution if the reference input is empty
  }
  submitReference(refNumber);
  // Check if the checkbox is checked before saving the reference number
  if (saveCheckbox.checked) {


    const isSIM = /^(.)\1+$/.test(refNumber);

    if (!isSIM && refNumber.trim() !== '') {
      let saveGEPCO = JSON.parse(localStorage.getItem('saveGEPCO')) || [];

      if (!saveGEPCO.includes(refNumber)) {
        let alreadyExists = false;

        for (const savedRef of saveGEPCO) {
          if (savedRef === refNumber) {
            alreadyExists = true;
            break;
          }
        }

        if (!alreadyExists) {
          saveGEPCO.push(refNumber);
          localStorage.setItem('saveGEPCO', JSON.stringify(saveGEPCO));
          updateReferenceList();
          document.getElementById('refNumber').value = '';
        } else {
          alert('This reference number is already saved.');
        }
      } else {

      }
    } else if (isSIM) {
      alert('Invalid reference number. SIM numbers (all characters the same) are not allowed.');
    } else {

    }
  }
  // If the checkbox is not checked, do not save the reference number
}


function submitReference(refNumber) {
  const link = `https://bill.pitc.com.pk/gepcobill/general?refno=${refNumber}`;
  localStorage.setItem('lastClickedReference', refNumber);
  window.location.href = link;
}

function cardClickHandler(refNumber) {
  submitReference(refNumber);
}

function updateReferenceList() {
  const saveGEPCO = JSON.parse(localStorage.getItem('saveGEPCO')) || [];
  const referenceList = document.getElementById('referenceList');
  referenceList.innerHTML = '';

  saveGEPCO.reverse();

  saveGEPCO.forEach(function (refNumber) {
    const card = document.createElement('div');
    card.className = 'card';

    const cardBody = document.createElement('div');
    cardBody.className = 'card-body d-flex justify-content-between align-items-center';

    const refSpan = document.createElement('span');
    refSpan.textContent = refNumber;
    refSpan.className = 'mr-auto';  // Align to the left

    const deleteButton = document.createElement('button');
    deleteButton.className = 'delete-button btn btn-danger';

    const deleteIcon = document.createElement('i');
    deleteIcon.className = 'fas fa-trash-alt';  // Font Awesome trash icon

    // Append the delete icon inside the delete button
    deleteButton.appendChild(deleteIcon);

    const deleteImage = document.createElement('img');
    deleteImage.src = 'graphic/delete-2-128.png'; // Replace with the path to your delete image
    deleteImage.width = 15;  // Adjust width as needed
    deleteImage.height = 15;  // Adjust height as needed
    deleteButton.appendChild(deleteImage);

    cardBody.appendChild(refSpan);
    cardBody.appendChild(deleteButton);
    card.appendChild(cardBody);
    referenceList.appendChild(card);

    // Attach the delete action to the delete button
    deleteButton.onclick = function (event) {
      event.stopPropagation();  // Prevent event propagation to the card
      deleteReference(refNumber);
    };

    card.onclick = function () {
      cardClickHandler(refNumber);
    };
  });
}



function deleteReference(refNumber) {
  const saveGEPCO = JSON.parse(localStorage.getItem('saveGEPCO')) || [];
  const updatedReferences = saveGEPCO.filter(item => item !== refNumber);
  localStorage.setItem('saveGEPCO', JSON.stringify(updatedReferences));
  updateReferenceList();
}

window.onload = function () {
  updateReferenceList();
};